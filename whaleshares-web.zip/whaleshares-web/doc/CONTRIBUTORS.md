This file contains a list of people who have made
large contributions to the Steemit.com codebase.



(not complete)



## Internationalization
 - @Undeadlol1 (Mihail Paley)
 - @ekitcho
 - @heimindanger
 - @fernando-sanz
 - @jza
 - @cheftony
 - @jumpeiyamane
    * Japanese
