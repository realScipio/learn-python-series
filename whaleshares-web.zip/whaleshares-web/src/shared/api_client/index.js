import ChainConfig from "./ChainConfig"

module.exports = {
  ChainConfig
}
