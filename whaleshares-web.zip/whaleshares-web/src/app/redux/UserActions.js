// export function setUser(user) {
//     return {
//         type: 'SET_USER',
//         username: user ? user.name : null
//     };
// }
