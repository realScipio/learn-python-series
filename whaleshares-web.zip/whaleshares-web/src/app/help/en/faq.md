# Whaleshares FAQ 

### PLEASE BE ADVISED:

The account creation/claim is ONLY open for BTS accounts that held WHALESHARE, BTS, BROWNIE.PTS on/before the snapshop date. (Bitshares Block 29222369 at 2018-08-01 03:18:51 UTC)

Other BTS accounts (not in the sharedrop) attempting to create will be rejected and the system will automatically refund the WHALESHARE tokens sent at the end of the claim period (September 15, 2018).

Successful claims will apply your sharedrop as vested WHALESTAKE and the claim closed.  The claim fee WHALESHARE tokens for successful claims are not returned or refunded.

## 1. I have a Whaleshares account,  how do I claim my sharedrop?

### STEP A:

Visit <a href="https://wls.services">wls.services</a>

### STEP B:

![wlshaveaccountclaim.png](https://whaleshares.io/imageupload_data/93a6904caaeb69a70fbaa3bd207cb5f8bb6f42f1)

### STEP C:

Visit <a href="https://wallet.bitshares.org">wallet.bitshares.org</a>

### STEP D:

![bitshare1b.png](https://whaleshares.io/imageupload_data/aff142d7a5c928fd1423a1f8531859fb811054e4)

### STEP E:

![bitshare2b.png](https://whaleshares.io/imageupload_data/4c8110f67e5facb1380bcf16fa6f28af658882f6)

### STEP F:

![bitshare3b.png](https://whaleshares.io/imageupload_data/5305dcfa2ada95d54970cbc40618eaba67a89d13)

### STEP G:

![bitshare1c.png](https://whaleshares.io/imageupload_data/fdc0f78223f96a81be0f2cc5d90974b6eddfcb1c)

### STEP H:

![haveaccountclaimI.png](https://whaleshares.io/imageupload_data/360bfbc4d8fd247d278a1362b9bdd59c1335e06c)

### STEP I:

![bitshare3c.png](https://whaleshares.io/imageupload_data/3365a885e94aaa4694dc03d6e1598f215e803fca)

### STEP J

![haveaccountclaimJ.png](https://whaleshares.io/imageupload_data/f7d03f5a9f8be9feee455b0b16754a51a02497d0)

## 2. I want a Whaleshares account but don't have any sharedrop to claim

### STEP A:

Visit <a href="https://wls.services">wls.services</a>

### STEP B:

![wlsmakeaccount.png](https://whaleshares.io/imageupload_data/e18bd76a99e0fbc31fe3cceaa9f74819d3f80db4)

### STEP C:

Visit <a href="https://wallet.bitshares.org">wallet.bitshares.org</a>

### STEP D:

![bitshare1b.png](https://whaleshares.io/imageupload_data/aff142d7a5c928fd1423a1f8531859fb811054e4)

### STEP E:

![bitshare2b.png](https://whaleshares.io/imageupload_data/4c8110f67e5facb1380bcf16fa6f28af658882f6)

### STEP F:

![bitshare3b.png](https://whaleshares.io/imageupload_data/5305dcfa2ada95d54970cbc40618eaba67a89d13)

### STEP G:

![bitshare1c.png](https://whaleshares.io/imageupload_data/fdc0f78223f96a81be0f2cc5d90974b6eddfcb1c)

### STEP H:

![needaccountI.png](https://whaleshares.io/imageupload_data/e1ef1df558940cb3bf9e441bb1e1476338dbfefc)

### STEP I:

![bitshare3c.png](https://whaleshares.io/imageupload_data/3365a885e94aaa4694dc03d6e1598f215e803fca)

### STEP J:

![needaccountclaimJ.png](https://whaleshares.io/imageupload_data/6ff63c749f9c5bfb80cd6eb5862e9687d9ef6d2f)

## 3. I need a Whaleshares account and want to claim my sharedrop

### STEP A:

Visit <a href="https://wls.services">wls.services</a>

### STEP B:

![wlsmakeaccount.png](https://whaleshares.io/imageupload_data/653d0c8f8e526cc68a01ca771854a34eaf435e58)

### STEP C:

Visit <a href="https://wallet.bitshares.org">wallet.bitshares.org</a>

### STEP D:

![bitshare1b.png](https://whaleshares.io/imageupload_data/aff142d7a5c928fd1423a1f8531859fb811054e4)

### STEP E:

![bitshare2b.png](https://whaleshares.io/imageupload_data/4c8110f67e5facb1380bcf16fa6f28af658882f6)

### STEP F:

![bitshare3b.png](https://whaleshares.io/imageupload_data/5305dcfa2ada95d54970cbc40618eaba67a89d13)

### STEP G:

![bitshare1c.png](https://whaleshares.io/imageupload_data/fdc0f78223f96a81be0f2cc5d90974b6eddfcb1c)

### STEP H:

![needaccountclaimI.png](https://whaleshares.io/imageupload_data/4bad72ef0796f0fe97605b7739ea42054ec1e466)

### STEP I:

![bitshare3c.png](https://whaleshares.io/imageupload_data/3365a885e94aaa4694dc03d6e1598f215e803fca)

### STEP J:

![needaccountclaimJ.png](https://whaleshares.io/imageupload_data/6ff63c749f9c5bfb80cd6eb5862e9687d9ef6d2f)


