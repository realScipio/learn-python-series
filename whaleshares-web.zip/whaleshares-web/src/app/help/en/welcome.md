## Welcome to Whaleshares!

You are one of the first people to join our exciting new social sharing platform where you are rewarded for the content you create and share with others. 

We are turning the social media revenue model on its head. The days of large companies controlling the personal data and content created by its users to make huge profits selling out to advertisers is coming to an end. Blockchain technology provides transparency and a new revenue model where the content creators and curators earn the revenue, not the big controlling companies. 

While we know earning rewards in the form of new "digital cryptocurrencies" can be a bit confusing at first, we have an ever-growing member support and <a href="/faq.html">FAQ section</a> on our website, as well as an amazing community of friendly people willing to help guide you and show you the how to get started. 

Wishing you all the best,

The Whaleshares Development Team
