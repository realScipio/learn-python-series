import React from 'react';

class Tos extends React.Component {
  render() {
    return (
      <div className="Tos row">
        <div className="column">
          <h1>Terms of Service</h1>
          <p>To be updated...</p>
        </div>
      </div>
    );
  }
}

module.exports = {
  path: 'tos.html',
  component: Tos
};
