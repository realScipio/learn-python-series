import React, {PropTypes} from 'react';
import {Link} from 'react-router';
import {connect} from 'react-redux';

export default class LpFooter extends React.Component {
  render() {
    return (
      <footer className="LpFooter row expanded">
      </footer>
    );
  }
}
