const list = `
`.trim().split('\n');

export default list;
