export default `
`.trim().split('\n');
