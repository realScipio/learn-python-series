export default {
  "nodes": [
    {
      "kind": "block",
      "type": "paragraph",
      "nodes": [
        {
          "kind": "text",
          "text": ""
        },
      ]
    }
  ]
}
